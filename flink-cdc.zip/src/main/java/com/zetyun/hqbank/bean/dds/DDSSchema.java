package com.zetyun.hqbank.bean.dds;

import lombok.Data;

/**
 * @author zhaohaojie
 * @date 2023-12-19 16:00
 */
@Data
public class DDSSchema {
    private String owner;
    private String table;
}

